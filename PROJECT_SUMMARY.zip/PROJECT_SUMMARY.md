# Smart Home Control System — Complete Project Summary
> Version 1.0.0 · React Native / Expo · Firebase · Arduino / ESP32

---

## 1. PROJECT OVERVIEW

**Smart Home Control** is a cross-platform mobile application (Android / iOS / Web) that lets a home owner remotely monitor and control physical smart-home devices in real time. The user interacts with a mobile app; the app reads and writes to Firebase (Auth + Firestore + Realtime Database); an Arduino/ESP32 hardware node polls Firebase and physically actuates the devices.

---

## 2. SOFTWARE TOOLS & TECHNOLOGIES

| Layer | Tool / Library | Version | Purpose |
|-------|---------------|---------|---------|
| **Runtime** | React Native | 0.81.5 | Cross-platform mobile UI |
| **Framework** | Expo | ~54.0.33 | Build, dev server, native modules |
| **Language** | JavaScript (JSX) | ES2022 | App source code |
| **Navigation** | React Navigation (Native Stack) | ^7 | Screen routing |
| **Backend-as-a-Service** | Firebase | ^12.12.0 | Auth, Firestore, Realtime DB |
| **Auth persistence** | AsyncStorage | ^3.0.2 | Keep user logged in |
| **Theme/Settings persistence** | AsyncStorage | same | Dark mode, temp unit |
| **Icons** | @expo/vector-icons (MaterialIcons) | ^15 | All UI icons |
| **Camera stream** | react-native-webview | 13.15.0 | Embed ESP32 MJPEG stream |
| **Animations** | React Native Animated API | built-in | Splash, pulse, FAB, shake |
| **Type checking** | TypeScript (dev only) | ~5.9.2 | Dev-time safety |
| **Linting** | ESLint + eslint-config-expo | ^9 | Code quality |
| **Hardware IDE** | Arduino IDE | — | Program ESP32/Arduino boards |
| **Hardware protocol** | Firebase REST / Arduino Firebase lib | — | Board reads/writes Firebase |

---

## 3. HARDWARE COMPONENTS

| Component | Role |
|-----------|------|
| **ESP32 / ESP32-S3** | Main microcontroller — Wi-Fi, camera, Firebase client |
| **ESP32-S3 (camera module)** | Streams live MJPEG video to a local URL stored in Firebase |
| **LED 1 (indoor)** | Controlled by `led1` flag in Firestore |
| **LED 2 (indoor)** | Controlled by `led2` flag in Firestore |
| **Servo / Relay (door lock)** | Controlled by `doorLocked` flag |
| **Buzzer / Alarm** | Activated by `alarmActive` flag |
| **Outdoor LED** | Auto-driven by PIR motion sensor state (`outdoorLed`) |
| **PIR Motion Sensor** | Detects movement → sets `motionDetected` in Firebase |
| **Temperature Sensor (DHT/NTC)** | Reads ambient temp → writes `temperature` to Firebase |
| **28BYJ-48 Stepper Motor** | Drives the sliding gate with smooth accel/decel |
| **Limit Switches (×2)** | Stop gate at fully-open and fully-closed positions |
| **Obstacle Sensor (IR)** | Stops gate if obstruction detected while closing |

---

## 4. FIREBASE ARCHITECTURE

### 4.1 Firebase Project
- **Project ID:** `smarthomesystem-a5ad1`
- **Auth Domain:** `smarthomesystem-a5ad1.firebaseapp.com`
- **Realtime DB URL:** `https://smarthomesystem-a5ad1-default-rtdb.firebaseio.com`

### 4.2 Firebase Authentication
- Provider: **Email / Password**
- Persistence: **AsyncStorage** (stays logged in across app restarts)
- Operations used: `signInWithEmailAndPassword`, `createUserWithEmailAndPassword`, `sendPasswordResetEmail`, `signOut`, `reauthenticateWithCredential`, `updatePassword`, `onAuthStateChanged`

### 4.3 Firestore Database (per-user device state + activity log)

```
Firestore
└── users/
    └── {uid}/
        ├── devices/
        │   └── state        ← single document, all device fields
        │       ├── led1              (boolean)
        │       ├── led2              (boolean)
        │       ├── doorLocked        (boolean)
        │       ├── alarmActive       (boolean)
        │       ├── temperature       (number, °C)
        │       ├── motionDetected    (boolean)
        │       ├── outdoorLed        (boolean)
        │       ├── streamUrl         (string | null)
        │       ├── gateCommand       ("open" | "close" | "stop")
        │       └── gateStatus        ("open"|"closed"|"opening"|"closing"|"stopped"|"obstacle_detected")
        └── activity/
            └── {auto-id}    ← activity log entries
                ├── icon      (MaterialIcons name string)
                ├── color     (hex string)
                ├── text      (human-readable description)
                └── timestamp (server timestamp)
```

### 4.4 Firebase Realtime Database (security / passcode)

```
Realtime DB
└── users/
    └── {uid}/
        ├── email     (string)
        └── passcode  (string, 4–6 digit numeric PIN)
```

### 4.5 Firebase Data Flow (App side)

1. App starts → `onAuthStateChanged` fires in `SystemContext`
2. If user logged in → subscribe (`onSnapshot`) to `users/{uid}/devices/state`
3. Any Firestore write updates the document → `onSnapshot` delivers the new state to all listeners (including the hardware board) in <1 s
4. Activity log → `addDoc` with `serverTimestamp()` → `onSnapshot` on the query delivers the newest 10 entries back to the app

### 4.6 Firebase Data Flow (Hardware side — Arduino/ESP32)

1. Board boots → connects to Wi-Fi
2. Board authenticates with Firebase (anonymous or REST token)
3. Board reads `users/{uid}/devices/state` → drives GPIO pins accordingly
4. Board writes sensor readings (`temperature`, `motionDetected`, `gateStatus`, `streamUrl`) back to same Firestore document
5. Loop repeats every few hundred milliseconds

---

## 5. APPLICATION ARCHITECTURE

### 5.1 Entry Point & Providers

```
App.js
 └── ThemeProvider          (src/context/ThemeContext.js)
      └── SettingsProvider  (src/context/SettingsContext.js)
           └── SystemProvider  (src/context/SystemContext.js)
                └── AppNavigator  (src/navigation/AppNavigator.js)
```

### 5.2 Context Providers

#### ThemeContext (`src/context/ThemeContext.js`)
- **State:** `isDark` (boolean), persisted in AsyncStorage key `@theme`
- **Exports:** `theme` (full color object — LIGHT or DARK), `isDark`, `toggleTheme()`
- **LIGHT theme primary:** `#2563eb` (blue); background `#f0f4ff`
- **DARK theme primary:** `#3b82f6`; background `#0f172a`

#### SettingsContext (`src/context/SettingsContext.js`)
- **State:** `tempUnit` ("C" or "F"), persisted in AsyncStorage key `@tempUnit`
- **Exports:** `tempUnit`, `setTempUnit(unit)`

#### SystemContext (`src/context/SystemContext.js`)
- **State:** `devices` object (all device fields), `activityLog` (array), `loading` (boolean)
- **Key functions:**

| Function | What it does |
|----------|-------------|
| `updateDevice(fields, logEntry?)` | Writes fields to Firestore; optionally adds an activity log entry |
| `logActivity(entry)` | Adds a timestamped entry to the activity subcollection |
| `simulateSensors()` | Generates random temperature (20–29°C) and motion (30% chance) values, writes to Firestore, logs activity if motion changed |
| `activateEmergencyMode()` | Sets `led1=true, led2=true, doorLocked=true, alarmActive=true` |
| `deactivateEmergencyMode()` | Sets `alarmActive=false` |
| `setLed1(value)` | Toggles LED 1, logs activity |
| `setLed2(value)` | Toggles LED 2, logs activity |
| `setDoorLocked(value)` | Locks/unlocks door, logs activity |
| `setGateCommand(cmd)` | Writes `gateCommand` to Firestore ("open"/"close"/"stop") |

- **Realtime subscriptions:** `onSnapshot` on devices document + `onSnapshot` on activity query (newest 10, ordered by timestamp desc)

### 5.3 Navigation Stack (`src/navigation/AppNavigator.js`)

```
Stack (initialRoute: Splash)
 ├── Splash
 ├── Login
 ├── Register
 ├── Passcode        ← new screen after Splash when user has a saved PIN
 ├── Home            ← main dashboard
 ├── Profile
 ├── Emergency
 ├── Support
 ├── About
 ├── ChangePassword
 └── Gate
```

---

## 6. SCREENS — FUNCTIONS & WORKFLOW

---

### 6.1 SplashScreen (`src/screens/SplashScreen.js`)

**Purpose:** Launch screen with animated branding; checks auth state and routes accordingly.

**Key elements:**
- Logo spring-pop + title slide-up + tagline fade-in animations
- Sequentially pulsing loading dots (loop animation)
- Minimum display time: **2600 ms**

**Workflow:**
1. Animations start immediately on mount
2. `onAuthStateChanged` fires → sets `targetRoute`:
   - User logged in → `"Passcode"`
   - No user → `"Login"`
3. After 2.6 s AND auth resolved → fade-out animation → `navigation.replace(targetRoute)`

**Functions:**
| Function | Role |
|----------|------|
| Entry animations (`useEffect`) | Logo, title, tagline, dots |
| `tryNavigate()` | Navigates only when both auth resolved and min time passed |
| `onAuthStateChanged` callback | Determines login state |

---

### 6.2 LoginScreen (`src/screens/LoginScreen.js`)

**Purpose:** Existing user authentication.

**State:** `email`, `password`, `rememberMe`, `showPassword`, error strings, `loading`

**Workflow:**
1. User enters email + password
2. `validate()` checks non-empty, password ≥ 6 chars
3. `signInWithEmailAndPassword(auth, email, password)` → on success `navigation.replace("Home")`
4. On failure → mapped error message shown in `Alert`
5. "Forgot Password?" → `sendPasswordResetEmail(auth, email)` → confirmation alert
6. "Register" link → `navigation.navigate("Register")`

**Functions:**
| Function | Role |
|----------|------|
| `validate()` | Field validation, sets error states |
| `handleLogin()` | Firebase sign-in, navigates to Home |
| `handleForgotPassword()` | Sends Firebase password reset email |

---

### 6.3 RegisterScreen (`src/screens/RegisterScreen.js`)

**Purpose:** New user registration — creates Firebase Auth account + stores passcode in Realtime DB.

**State:** `email`, `password`, `confirmPassword`, `passcode` (4–6 digit PIN), `confirmPasscode`, `showPassword`, `errors`, `loading`

**Workflow:**
1. User fills email, password, confirm password, passcode, confirm passcode
2. `validate()` checks all fields; passcode must be numeric, ≥ 4 digits
3. `createUserWithEmailAndPassword(auth, email, password)` → Firebase creates user
4. `set(ref(rtdb, "users/{uid}"), { email, passcode })` → passcode stored in Realtime DB
5. `navigation.replace("Home")`

**Functions:**
| Function | Role |
|----------|------|
| `validate()` | Full form validation with inline error display |
| `handleRegister()` | Creates Auth user + saves passcode to Realtime DB |

---

### 6.4 PasscodeScreen (`src/screens/PasscodeScreen.js`)

**Purpose:** PIN lock screen shown after Splash when a returning user has a saved passcode.

**State:** `pin` (entered digits), `attempts`, `storedCode` (fetched from Realtime DB), `loading`, `errorMsg`

**Workflow:**
1. Mounts → `get(ref(rtdb, "users/{uid}/passcode"))` to fetch stored PIN
   - No PIN stored → `navigation.replace("Home")` (skip passcode)
2. User taps numeric pad → digits fill dots; auto-submits when length matches stored PIN
3. `submitPin(entered)`:
   - Match → `navigation.replace("Home")`
   - Mismatch → `attempts++`, shake animation, show remaining attempts
   - 3 wrong attempts → `signOut(auth)` → `navigation.replace("Login")`
4. "Forgot Passcode?" → confirmation → `signOut(auth)` → Login

**Functions:**
| Function | Role |
|----------|------|
| `handleDigit(digit)` | Appends digit; auto-calls `submitPin` when full |
| `handleDelete()` | Removes last digit |
| `submitPin(entered)` | Validates PIN, handles lockout |
| `shake()` | Shake animation on wrong PIN |
| `handleForgot()` | Sign out and redirect to Login |

---

### 6.5 HomeScreen (`src/screens/HomeScreen.js`)

**Purpose:** Main dashboard — shows all device states, sensors, camera, gate preview, activity log, and navigation FAB.

**State:** `isCameraFullScreen`, `currentDateTime` (clock), `menuOpen` (FAB)

**Animated values:** `fabAnimation`, `motionRingScale/Opacity`, `emergencyOpacity`

**Sections & Workflow:**

| Section | What it shows | Interaction |
|---------|--------------|-------------|
| **Header** | App brand, user email, live clock, date | Tap avatar → Profile |
| **Stat chips** | Online/ALERT status, temperature (°C/°F), active device count | Read-only |
| **Emergency banner** | Flashing red banner (only when `alarmActive = true`) | Read-only |
| **Live Camera card** | WebView with ESP32 stream URL; "LIVE" pill; fullscreen button | Tap expand → fullscreen modal |
| **Sliding Gate card** | Animated gate visual showing current `gateStatus` | Tap → GateScreen |
| **Devices grid (4 cards)** | Indoor LED 1, Indoor LED 2, Door Lock (with toggles), Outdoor LED (read-only auto) | Toggle switch → updates Firestore |
| **Sensors row** | Temperature card, Motion card (with pulse animation) | Read-only, auto-refreshes |
| **Activity log** | Newest 10 events from Firestore with icon, text, timestamp | Read-only |
| **FAB menu** | Floating action button expands to: Profile, Emergency, Support, About | Tap main FAB → expand; tap item → navigate |
| **Fullscreen camera modal** | Full-screen WebView or placeholder; clock overlay | Tap close → dismiss |

**Key intervals:**
- Clock: updates every **1 s** (`setInterval`)
- Sensor simulation: runs every **5 s** (`simulateSensors()`)

**Functions:**
| Function | Role |
|----------|------|
| Motion pulse `useEffect` | Starts/stops pulse ring animation when `motionDetected` changes |
| Emergency flash `useEffect` | Starts/stops flashing when `alarmActive` changes |
| Clock `useEffect` | `setInterval` every 1 s |
| Sensor `useEffect` | `setInterval` every 5 s calling `simulateSensors()` |
| `displayTemp` | Converts °C → °F if user preference is Fahrenheit |
| `toggleFab()` | Animates FAB menu open/close |
| Device toggles | Call `setLed1`, `setLed2`, `setDoorLocked` from SystemContext |

---

### 6.6 GateScreen (`src/screens/GateScreen.js`)

**Purpose:** Dedicated sliding gate control panel.

**State:** `lastCmd` (last sent command)

**Status states:** `open`, `closed`, `opening`, `closing`, `stopped`, `obstacle_detected`
Each has its own color, background, icon, and label.

**Workflow:**
1. Reads `gateStatus` and `setGateCommand` from `useSystem()`
2. Status card shows animated icon (spinning while moving, pulsing on obstacle)
3. Control card has 3 buttons: **Open**, **Stop**, **Close**
   - Open disabled if already open or opening
   - Close disabled if already closed or closing
   - Stop always enabled
4. `sendCommand(cmd)` → calls `setGateCommand(cmd)` → writes `gateCommand` to Firestore
5. Arduino polls `gateCommand` → runs the stepper motor accordingly → writes `gateStatus` back
6. Safety features card explains limit switches, obstacle reversal, smooth motion

**Animations:**
- Spinning icon while `isMoving` (360° loop)
- Pulsing icon on `obstacle_detected`

---

### 6.7 EmergencyScreen (`src/screens/EmergencyScreen.js`)

**Purpose:** One-tap emergency mode control.

**Reads from SystemContext:** `alarmActive`, `activateEmergencyMode`, `deactivateEmergencyMode`

**Workflow:**
1. Shows what Emergency Mode does (lights on, doors locked, alarm triggered)
2. Displays current status (ACTIVE / INACTIVE)
3. Toggle button:
   - If inactive → `activateEmergencyMode()` → writes `{led1:true, led2:true, doorLocked:true, alarmActive:true}` to Firestore + logs activity
   - If active → `deactivateEmergencyMode()` → writes `{alarmActive:false}` + logs activity
4. Alert confirms the action to the user

---

### 6.8 ProfileScreen (`src/screens/ProfileScreen.js`)

**Purpose:** User account info, appearance settings, and account actions.

**Reads:** `auth.currentUser` (email, displayName), `useTheme()`, `useSettings()`

**Sections:**
1. **Avatar card** — shows user icon, email, "Home Owner" badge
2. **Appearance section:**
   - Dark Mode toggle (Switch) → `toggleTheme()` → persisted in AsyncStorage
   - Temperature unit toggle (°C / °F) → `setTempUnit()` → persisted in AsyncStorage
3. **Account section:**
   - Change Password → `navigation.navigate("ChangePassword")`
   - Logout → `Alert` confirmation → `signOut(auth)` → `navigation.replace("Login")`

---

### 6.9 ChangePasswordScreen (`src/screens/ChangePasswordScreen.js`)

**Purpose:** Securely update account password.

**State:** `currentPassword`, `newPassword`, `confirmPassword`, show-password flags, `loading`

**Workflow:**
1. Validate: all fields non-empty, new password ≥ 6 chars, passwords match
2. `EmailAuthProvider.credential(user.email, currentPassword)` — build re-auth credential
3. `reauthenticateWithCredential(user, credential)` — verify current password with Firebase
4. `updatePassword(user, newPassword)` — set new password
5. On success: Alert → `navigation.goBack()`
6. On failure: mapped Firebase error code → Alert

**Functions:**
| Function | Role |
|----------|------|
| `handleChangePassword()` | Full re-auth + password update flow |

---

### 6.10 SupportScreen (`src/screens/SupportScreen.js`)

**Purpose:** Emergency contact information with one-tap calling.

**Data:** Two hard-coded support phone numbers (Primary: 76423892, Secondary: 76539628)

**Workflow:**
- Tap call button → `Linking.openURL("tel:{number}")` → opens phone dialer

---

### 6.11 AboutScreen (`src/screens/AboutScreen.js`)

**Purpose:** Static informational screen describing the app.

**Content:** Overview, main feature list, purpose, version (1.0.0)

---

## 7. SHARED COMPONENT

### DeviceCard (`src/components/DeviceCard.js`)

**Props:**
| Prop | Type | Purpose |
|------|------|---------|
| `title` | string | Device name |
| `value` | string | Current state label |
| `icon` | string | MaterialIcons name |
| `iconColor` | string | Icon + badge tint |
| `active` | boolean | Highlights card border/background |
| `showSwitch` | boolean | Shows ON/OFF toggle |
| `switchValue` | boolean | Current switch state |
| `onSwitchChange` | function | Toggle handler |
| `status` | string | Badge text ("Online", "Offline", "Auto: On", etc.) |

**Badge color logic:**
- `"Online"` → green
- `"Offline"` → red
- Starts with `"Auto"` → blue
- Anything else → amber

---

## 8. DATA MODEL — ALL DEVICE FIELDS

| Field | Type | Default | Controlled by |
|-------|------|---------|--------------|
| `led1` | boolean | false | User (app toggle) |
| `led2` | boolean | true | User (app toggle) |
| `doorLocked` | boolean | true | User (app toggle) |
| `alarmActive` | boolean | false | Emergency mode |
| `temperature` | number | 24 | Sensor / simulated |
| `motionDetected` | boolean | false | PIR sensor / simulated |
| `outdoorLed` | boolean | false | Auto-driven by motionDetected |
| `streamUrl` | string\|null | null | ESP32-S3 camera board |
| `gateCommand` | string | "stop" | User (GateScreen buttons) |
| `gateStatus` | string | "closed" | Arduino stepper controller |

---

## 9. COMPLETE AUTHENTICATION & NAVIGATION FLOW

```
App Launch
    │
    ▼
SplashScreen (2.6s + animations)
    │
    ├─ User session exists? ─YES─► PasscodeScreen
    │                                   │
    │                          PIN correct?
    │                            YES ──► HomeScreen
    │                            NO (3x) ► signOut ─► LoginScreen
    │
    └─ No session ──────────────► LoginScreen
                                       │
                          ┌────────────┴────────────┐
                          ▼                         ▼
                    handleLogin              "Register" link
                  (signIn + replace          ► RegisterScreen
                   "Passcode"/"Home")          (createUser +
                                               save passcode
                                               ► HomeScreen)

HomeScreen (main dashboard)
    │   FAB menu expands
    ├──► ProfileScreen
    │       ├──► ChangePasswordScreen
    │       └──► signOut ► LoginScreen
    ├──► EmergencyScreen
    ├──► SupportScreen
    ├──► AboutScreen
    └──► GateScreen
```

---

## 10. ARDUINO / ESP32 WORKFLOW

### 10.1 Setup (runs once on boot)

```
1. Initialize Serial (debug output)
2. Connect to Wi-Fi (SSID + password)
3. Initialize Firebase client:
   - Set Firebase credentials (project URL, auth token)
   - Enable SSL
4. Configure GPIO pins:
   - LED 1 pin → OUTPUT
   - LED 2 pin → OUTPUT
   - Door lock servo/relay pin → OUTPUT
   - Alarm/buzzer pin → OUTPUT
   - PIR sensor pin → INPUT
   - Temperature sensor pin → INPUT
   - Obstacle sensor pin → INPUT
   - Stepper motor pins (4 pins) → OUTPUT
   - Limit switch pins (2) → INPUT_PULLUP
5. (ESP32-S3 only) Initialize camera module → start MJPEG stream server
6. Write camera stream URL to Firebase: users/{uid}/devices/state/streamUrl
```

### 10.2 Main Loop (runs every ~200–500 ms)

```
LOOP:
│
├─ READ from Firebase (Firestore or REST):
│   users/{uid}/devices/state
│   → led1, led2, doorLocked, alarmActive, gateCommand
│
├─ ACTUATE outputs:
│   ├─ led1 → digitalWrite(LED1_PIN, led1)
│   ├─ led2 → digitalWrite(LED2_PIN, led2)
│   ├─ doorLocked → servo.write(locked ? 0 : 90)  OR  relay HIGH/LOW
│   └─ alarmActive → tone(BUZZER_PIN, 1000) / noTone()
│
├─ READ sensors:
│   ├─ temperature = analogRead(TEMP_PIN) → convert to °C
│   ├─ motionDetected = digitalRead(PIR_PIN)
│   └─ outdoorLed = motionDetected   (auto-logic)
│
├─ WRITE sensor data to Firebase:
│   users/{uid}/devices/state:
│   { temperature, motionDetected, outdoorLed }
│
└─ GATE CONTROL logic:
    ├─ if gateCommand == "open"  AND gateStatus != "open"
    │   → start stepper forward
    │   → write gateStatus = "opening"
    │   → watch OPEN limit switch → stop → write gateStatus = "open"
    │
    ├─ if gateCommand == "close" AND gateStatus != "closed"
    │   → start stepper backward
    │   → write gateStatus = "closing"
    │   → watch CLOSE limit switch → stop → write gateStatus = "closed"
    │   → watch obstacle sensor → stop → reverse slightly
    │     → write gateStatus = "obstacle_detected"
    │
    └─ if gateCommand == "stop"
        → stop stepper immediately
        → write gateStatus = "stopped"
```

### 10.3 Camera Stream (ESP32-S3)

```
1. Camera initialized with OV2640 sensor
2. HTTP server started on local IP (port 80)
3. /stream endpoint returns MJPEG stream
4. URL (e.g. "http://192.168.1.x/stream") written to Firebase:
   users/{uid}/devices/state/streamUrl
5. App reads streamUrl → displays it in WebView
```

---

## 11. SECURITY FEATURES

| Feature | Implementation |
|---------|---------------|
| **Email/Password Auth** | Firebase Authentication |
| **Session persistence** | AsyncStorage; user stays logged in until explicit sign-out |
| **PIN lock (Passcode)** | 4–6 digit PIN stored in Realtime DB; required on every app launch |
| **Brute-force protection** | 3 wrong PIN attempts → automatic sign-out |
| **Re-authentication on password change** | `reauthenticateWithCredential` required before `updatePassword` |
| **Per-user data isolation** | All Firestore data stored under `users/{uid}/...` |
| **Password reset** | Firebase `sendPasswordResetEmail` |
| **"Forgot passcode"** | Signs the user out, requires full email/password re-login |

---

## 12. KEY DATA FLOWS SUMMARY

### Turning on LED 1 (end-to-end)

```
User taps LED 1 switch (HomeScreen)
    │
    ▼
setLed1(true)  [SystemContext]
    │
    ▼
updateDevice({ led1: true }, { icon: "lightbulb", color: "#f59e0b", text: "LED 1 turned on" })
    │
    ├──► updateDoc("users/{uid}/devices/state", { led1: true })  [Firestore write]
    │
    └──► addDoc("users/{uid}/activity", { icon, color, text, timestamp })  [Firestore write]
              │
              ▼
         onSnapshot fires → activityLog updates in UI

Arduino loop reads led1 = true from Firebase
    │
    ▼
digitalWrite(LED1_PIN, HIGH)  → Physical LED turns ON
```

### Sensor update (end-to-end)

```
Every 5s: simulateSensors() [HomeScreen → SystemContext]
    │
    ▼
Random temperature (20–29°C) + random motion (30% probability)
    │
    ▼
updateDoc("users/{uid}/devices/state", { temperature, motionDetected, outdoorLed })
    │
    ▼
onSnapshot fires → HomeScreen re-renders temperature chip + motion sensor card

(In production: Arduino writes these values, not simulated by app)
```

### Gate open command (end-to-end)

```
User taps "Open Gate" button (GateScreen)
    │
    ▼
setGateCommand("open")  [SystemContext]
    │
    ▼
updateDoc("users/{uid}/devices/state", { gateCommand: "open" })
    │
    ▼
Arduino reads gateCommand = "open"
    │
    ├──► Writes gateStatus = "opening" → App shows "Opening…" with spinning icon
    ├──► Runs 28BYJ-48 stepper motor forward
    ├──► Limit switch triggers → motor stops
    └──► Writes gateStatus = "open" → App shows "Open" with green icon
```

---

## 13. FILE STRUCTURE (ACTIVE APP)

```
smart-home-app/
├── App.js                          ← Root: wraps providers, renders AppNavigator
├── authService.js                  ← Standalone auth service (registerUser, loginUser, logoutUser)
├── deviceService.js                ← Standalone device service (RTDB-based, legacy)
├── userService.js                  ← Standalone user profile service (RTDB-based)
├── package.json                    ← Dependencies & scripts
└── src/
    ├── firebase/
    │   └── config.js               ← Firebase init: exports auth, db (Firestore), rtdb (Realtime DB)
    ├── context/
    │   ├── SystemContext.js        ← Global device state, Firestore sync, all actions
    │   ├── ThemeContext.js         ← Light/dark theme, persisted
    │   └── SettingsContext.js      ← Temperature unit preference, persisted
    ├── navigation/
    │   └── AppNavigator.js         ← Native stack navigator, all screen registrations
    ├── components/
    │   └── DeviceCard.js           ← Reusable device tile (icon, badge, value, switch)
    └── screens/
        ├── SplashScreen.js         ← Animated launch + auth check
        ├── LoginScreen.js          ← Email/password login
        ├── RegisterScreen.js       ← Registration + passcode setup
        ├── PasscodeScreen.js       ← PIN entry (Realtime DB)
        ├── HomeScreen.js           ← Main dashboard
        ├── GateScreen.js           ← Gate control panel
        ├── EmergencyScreen.js      ← Emergency mode
        ├── ProfileScreen.js        ← User settings + logout
        ├── ChangePasswordScreen.js ← Re-auth + password update
        ├── SupportScreen.js        ← Emergency contact calling
        └── AboutScreen.js          ← Static app info
```

---

## 14. SUMMARY TABLE — FUNCTIONS BY SCREEN

| Screen | Key Functions | Firebase Calls |
|--------|--------------|----------------|
| SplashScreen | Entry animations, `tryNavigate()` | `onAuthStateChanged` |
| LoginScreen | `validate()`, `handleLogin()`, `handleForgotPassword()` | `signInWithEmailAndPassword`, `sendPasswordResetEmail` |
| RegisterScreen | `validate()`, `handleRegister()` | `createUserWithEmailAndPassword`, RTDB `set` (passcode) |
| PasscodeScreen | `handleDigit()`, `handleDelete()`, `submitPin()`, `shake()`, `handleForgot()` | RTDB `get` (passcode), `signOut` |
| HomeScreen | Motion/emergency animations, clock interval, sensor interval, `toggleFab()`, `displayTemp` | Via SystemContext (Firestore `onSnapshot`) |
| GateScreen | `sendCommand(cmd)` | Via SystemContext (`setGateCommand` → Firestore) |
| EmergencyScreen | `handleEmergencyToggle()` | Via SystemContext (`activateEmergencyMode` / `deactivateEmergencyMode`) |
| ProfileScreen | `handleLogout()`, theme toggle, temp unit toggle | `signOut`, AsyncStorage |
| ChangePasswordScreen | `handleChangePassword()` | `reauthenticateWithCredential`, `updatePassword` |
| SupportScreen | `handleCall(number)` | None (Linking API) |
| AboutScreen | Static display | None |
| **SystemContext** | `updateDevice()`, `logActivity()`, `simulateSensors()`, `activateEmergencyMode()`, `deactivateEmergencyMode()`, `setLed1/2()`, `setDoorLocked()`, `setGateCommand()` | Firestore `onSnapshot`, `updateDoc`, `setDoc`, `addDoc` |
